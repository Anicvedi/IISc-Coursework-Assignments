


create_clock -period 10.000 -name clk -waveform {0.000 5.000} -add [get_ports clk]

set_switching_activity -toggle_rate 0.000 -static_probability 0.100 [get_nets rst_IBUF]
set_switching_activity -toggle_rate 0.000 -static_probability 0.000 [get_nets rst_IBUF]
